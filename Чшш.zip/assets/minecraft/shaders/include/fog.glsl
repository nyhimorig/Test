#ifndef MINECRAFT_FOG_GLSL
#define MINECRAFT_FOG_GLSL

layout(std140) uniform Fog {
    vec4 FogColor;
    float FogEnvironmentalStart;
    float FogEnvironmentalEnd;
    float FogRenderDistanceStart;
    float FogRenderDistanceEnd;
    float FogSkyEnd;
    float FogCloudsEnd;
};

float linear_fog_value(float vertexDistance, float fogStart, float fogEnd) {
    if (vertexDistance <= fogStart) {
        return 0.0;
    } else if (vertexDistance >= fogEnd) {
        return 1.0;
    }

    return (vertexDistance - fogStart) / (fogEnd - fogStart);
}

float total_fog_value(float sphericalVertexDistance, float cylindricalVertexDistance, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd) {
    return max(linear_fog_value(sphericalVertexDistance, environmentalStart, environmantalEnd), linear_fog_value(cylindricalVertexDistance, renderDistanceStart, renderDistanceEnd));
}

vec4 apply_fog(vec4 inColor, float sphericalVertexDistance, float cylindricalVertexDistance, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd, vec4 fogColor) {
    float fogValue = total_fog_value(sphericalVertexDistance, cylindricalVertexDistance, environmentalStart, environmantalEnd, renderDistanceStart, renderDistanceEnd);
    return vec4(mix(inColor.rgb, fogColor.rgb, fogValue * fogColor.a), inColor.a);
}

#ifdef VHS_WORLD_FOG
float vhsFogHash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

float vhsFogNoise(vec2 p) {
    vec2 cell = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);

    float a = vhsFogHash(cell);
    float b = vhsFogHash(cell + vec2(1.0, 0.0));
    float c = vhsFogHash(cell + vec2(0.0, 1.0));
    float d = vhsFogHash(cell + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

vec3 vhsSmokeColor(vec2 screenPosition, float time) {
    vec2 smokePosition = screenPosition * 0.0012 + vec2(time * 0.0015, -time * 0.001);
    float drift = time * 0.0007;
    smokePosition += 0.12 * vec2(sin(smokePosition.y * 1.2 + drift), cos(smokePosition.x * 0.8 - drift));
    float smokeNoise = vhsFogNoise(smokePosition);
    float smoke = smoothstep(0.25, 0.78, smokeNoise);
    vec3 smokeColor = mix(vec3(0.42, 0.44, 0.46), vec3(0.62, 0.64, 0.66), smoke);
    float shadow = (1.0 - smoothstep(0.12, 0.34, smokeNoise)) * 0.22;
    return mix(smokeColor, vec3(0.36, 0.38, 0.40), shadow);
}

vec4 vhsCameraEffect(vec4 color, vec2 screenPosition, vec2 screenSize, float time) {
    vec2 screenUv = screenPosition / max(screenSize, vec2(1.0));
    float frame = floor(time * 10.0);
    float grain = vhsFogHash(floor(screenPosition * 0.5) + vec2(frame, frame * 0.37)) - 0.5;
    float scanline = 0.5 + 0.5 * sin((screenPosition.y + floor(time * 4.0)) * 3.14159);
    float trackingLine = 1.0 - smoothstep(0.0, 0.006, abs(screenUv.y - fract(time * 0.03)));
    float colorFringe = smoothstep(0.25, 0.9, abs(screenUv.x - 0.5) * 2.0) * 0.012;

    color.rgb *= 1.0 - scanline * 0.025 - trackingLine * 0.04;
    color.rgb += grain * 0.025;
    color.r += color.r * colorFringe;
    color.b -= color.b * colorFringe;
    return color;
}

float vhsVignette(vec2 screenPosition, vec2 screenSize) {
    vec2 centered = abs(screenPosition / max(screenSize, vec2(1.0)) - 0.5) * 2.0;
    float edge = length(centered);
    return 1.0 - 0.12 * smoothstep(0.75, 1.4, edge);
}

float vhsSkyHaze() {
    return 1.0;
}

vec4 apply_vhs_world_fog(vec4 inColor, float sphericalVertexDistance, float cylindricalVertexDistance, float environmentalStart, float environmentalEnd, float renderDistanceStart, float renderDistanceEnd, vec4 fogColor, vec2 screenPosition, float time) {
    if (fogColor.a <= 0.0 || renderDistanceEnd <= 0.0) {
        return inColor;
    }

    float distanceHaze = smoothstep(4.0, 20.0, sphericalVertexDistance);

    if (distanceHaze <= 0.0) {
        return apply_fog(inColor, sphericalVertexDistance, cylindricalVertexDistance, environmentalStart, environmentalEnd, renderDistanceStart, renderDistanceEnd, fogColor);
    }

    vec3 smokeColor = vhsSmokeColor(screenPosition, time);
    if (distanceHaze >= 1.0) {
        return vec4(smokeColor, inColor.a);
    }

    vec4 color = apply_fog(inColor, sphericalVertexDistance, cylindricalVertexDistance, environmentalStart, environmentalEnd, renderDistanceStart, renderDistanceEnd, fogColor);
    color.rgb = mix(color.rgb, smokeColor, distanceHaze);
    return color;
}

vec4 apply_vhs_entity_fog(vec4 inColor, float sphericalVertexDistance, float cylindricalVertexDistance, float environmentalStart, float environmentalEnd, float renderDistanceStart, float renderDistanceEnd, vec4 fogColor, vec2 screenPosition, float time) {
    if (fogColor.a <= 0.0 || renderDistanceEnd <= 0.0) {
        return inColor;
    }

    vec4 color = apply_fog(inColor, sphericalVertexDistance, cylindricalVertexDistance, environmentalStart, environmentalEnd, renderDistanceStart, renderDistanceEnd, fogColor);
    float distanceHaze = smoothstep(4.0, 20.0, sphericalVertexDistance);
    color.rgb = mix(color.rgb, vhsSmokeColor(screenPosition, time), distanceHaze);
    color.a *= 1.0 - distanceHaze;
    return color;
}

vec4 apply_vhs_flat_world_fog(vec4 inColor, float sphericalVertexDistance, float cylindricalVertexDistance, float environmentalStart, float environmentalEnd, float renderDistanceStart, float renderDistanceEnd, vec4 fogColor, vec2 screenPosition, float time) {
    float distanceHaze = smoothstep(4.0, 20.0, sphericalVertexDistance);

    if (distanceHaze <= 0.0) {
        return apply_fog(inColor, sphericalVertexDistance, cylindricalVertexDistance, environmentalStart, environmentalEnd, renderDistanceStart, renderDistanceEnd, fogColor);
    }

    vec3 smokeColor = vhsSmokeColor(screenPosition, time);
    if (distanceHaze >= 1.0) {
        return vec4(smokeColor, inColor.a);
    }

    vec4 color = apply_fog(inColor, sphericalVertexDistance, cylindricalVertexDistance, environmentalStart, environmentalEnd, renderDistanceStart, renderDistanceEnd, fogColor);
    color.rgb = mix(color.rgb, smokeColor, distanceHaze);
    return color;
}
#endif

float fog_spherical_distance(vec3 pos) {
    return length(pos);
}

float fog_cylindrical_distance(vec3 pos) {
    float distXZ = length(pos.xz);
    float distY = abs(pos.y);
    return max(distXZ, distY);
}

#endif
