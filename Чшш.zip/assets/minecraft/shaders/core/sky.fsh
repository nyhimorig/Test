#version 330
#extension GL_ARB_separate_shader_objects : require

#define VHS_WORLD_FOG
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;

layout(location = 0) out vec4 fragColor;

void main() {
    vec3 color = vhsSmokeColor(gl_FragCoord.xy, GameTime * 1200.0);
    color *= vhsVignette(gl_FragCoord.xy, ScreenSize);
    color = vhsCameraEffect(vec4(color, 1.0), gl_FragCoord.xy, ScreenSize, GameTime * 1200.0).rgb;
    fragColor = vec4(color, 1.0);
}
