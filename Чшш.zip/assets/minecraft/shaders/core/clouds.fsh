#version 330
#extension GL_ARB_separate_shader_objects : require

#define VHS_WORLD_FOG
#include <minecraft:fog.glsl>
#include <minecraft:oit.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in float vertexDistance;
layout(location = 1) in vec4 vertexColor;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif
    return color;
}

void main() {
    vec4 color = vertexColor;
    #ifndef OIT_DEPTH_BOUNDS
    color.a *= 1.0f - linear_fog_value(vertexDistance, 0, FogCloudsEnd);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    float haze = vhsSkyHaze();
    color.rgb = mix(color.rgb, vhsSmokeColor(gl_FragCoord.xy, GameTime * 1200.0), haze);
    color.rgb *= vhsVignette(gl_FragCoord.xy, ScreenSize);
    color = vhsCameraEffect(color, gl_FragCoord.xy, ScreenSize, GameTime * 1200.0);
    fragColor = calculateFinalColor(color);
    #endif
}
