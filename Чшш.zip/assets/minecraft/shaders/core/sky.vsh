#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;

void main() {
    vec3 skyPosition = Position;
    skyPosition.y -= length(Position.xz) * 0.5;
    gl_Position = ProjMat * ModelViewMat * vec4(skyPosition, 1.0);

    sphericalVertexDistance = fog_spherical_distance(skyPosition);
    cylindricalVertexDistance = fog_cylindrical_distance(skyPosition);
}
